package TEST;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BASE_CLASS.utilities;
import BASE_CLASS.wait_type;
import EXCEL_UTILITY.excel_d;
import PAGES.add_tocart;
import PAGES.homepage;
import PAGES.reg_pom;

public class demo_test extends excel_d {
	
	WebDriver dr;
	
	utilities ut;
	wait_type wt;
	
	reg_pom rp;
	homepage hp;
	add_tocart ap;
	
	String url="https://www.demoblaze.com/";
	
	@BeforeMethod
	public void bm() {
		ut=new utilities();
		dr=ut.launch_browser("CHROME", url);
		
	}
	
	
  @Test(dataProvider="project")
  public void f(String s_uid,String s_pwd,String l_uid,String l_pwd,String el,String cn,String tm) throws InterruptedException {
	  
	  wt=new wait_type(dr);
	  ut=new utilities();
	  
	  rp=new reg_pom(dr);
	  rp.do_reg_login(s_uid, s_pwd, l_uid, l_pwd);
	  
	  hp=new homepage(dr);
	  hp.add_product1();
	  
	  Thread.sleep(3000);
	  ap=new add_tocart(dr);
	  ap.add_cart(el, cn, tm);
	  
  }
  
  
  @DataProvider(name="project")
  public String[][] prov_data(){
	  
	  get_test_data();
	  return testdata;
  }
  
//  @AfterMethod
//  public void am()
//  {
//	  dr.close();
//  }
  
}
