package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BASE_CLASS.wait_type;

public class homepage {

	WebDriver dr;
	wait_type wt;
	
	public homepage(WebDriver dr)
	{
		this.dr=dr;
		wt=new wait_type(dr);
	}
	
	By product1=By.xpath("//div[@id='tbodyid']/div[5]/div/a");
	
	
	public void set_product1()
	{
		WebElement we_prod=wt.elementToBeClickable(product1, 40);
		we_prod.click();
	}
	
	public void add_product1()
	{
		this.set_product1();
	}
	
	
}
